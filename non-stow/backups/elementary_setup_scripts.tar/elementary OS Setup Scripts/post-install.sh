DEVICE_TARGET="/dev/sda"
cryptsetup luksOpen ${DEVICE_TARGET}2 lvm_crypt
sleep 8 #give system some time...

mount /dev/mapper/ubuntu-root /mnt
mount ${DEVICE_TARGET}1 /mnt/boot
mount -o bind /dev /mnt/dev
mount -t proc proc /mnt/proc
mount -t sysfs sys /mnt/sys
cp /etc/resolv.conf /mnt/etc/resolv.conf #not everyone got a router...

chroot /mnt /bin/bash  << EOF
apt-get install --yes cryptsetup lvm2
echo "lvm_crypt UUID=$(cryptsetup luksUUID ${DEVICE_TARGET}2) none luks" > /etc/crypttab
#printf "lukslvm\tUUID=%s\tnone\tluks\n" "$(cryptsetup luksUUID ${DEVICE_TARGET}2)" | tee -a /etc/crypttab 
echo "dm-crypt" >> /etc/modules
echo "ohci_pci" >> /etc/initramfs-tools/modules
update-initramfs -u -k all -c
exit
EOF
sync
umount /mnt/sys
umount /mnt/proc
umount /mnt/boot
swapoff -a

