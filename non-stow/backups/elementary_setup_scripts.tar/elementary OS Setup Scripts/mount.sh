DEVICE_TARGET="/dev/sda"
mount ${DEVICE_TARGET}1 /mnt/boot
mount -o bind /dev /mnt/dev
mount -t proc proc /mnt/proc
mount -t sysfs sys /mnt/sys
