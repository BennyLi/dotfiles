#!/usr/bin/env bash

# sudo add-apt-repository --yes ppa:captiva/ppa
# sudo sh -c 'cat >/etc/apt/preferences.d/captiva-ppa-captiva-icon-theme-pin <<EOL
# Package: *
# Pin: release o=LP-PPA-captiva-ppa
# Pin-Priority: -1
#
# Package: captiva-icon-theme
# Pin: release o=LP-PPA-captiva-ppa
# Pin-Priority: 500
# EOL'
#
# sudo apt-get update
# sudo apt-get install --yes captiva-icon-theme
