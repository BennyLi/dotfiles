#!/usr/bin/env bash

PIN_FILE_NAME=noobslab-icons-ultra-flat-icons-pin

sudo add-apt-repository --yes ppa:noobslab/icons
if [ -e /etc/apt/preferences.d/$PIN_FILE_NAME ]; then
  sudo rm /etc/apt/preferences.d/$PIN_FILE_NAME
fi
sudo sh -c "cat >/etc/apt/preferences.d/$PIN_FILE_NAME <<EOL
Package: *
Pin: release o=LP-PPA-noobslab-icons
Pin-Priority: -1

Package: ultra-flat-icons
Pin: release o=LP-PPA-noobslab-icons
Pin-Priority: 500
EOL"

sudo apt-get update
sudo apt-get install --yes ultra-flat-icons
