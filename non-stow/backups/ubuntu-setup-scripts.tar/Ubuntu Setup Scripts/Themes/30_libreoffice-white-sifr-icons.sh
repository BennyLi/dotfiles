#!/usr/bin/env bash

# Install white icons for LibreOffice

sudo apt-get install --yes libreoffice-style-sifr

# FROM https://raw.githubusercontent.com/denydias/coldhex/master/tools/libreoffice/sifr_mogrify
# Set original Sifr path
SIFRPATH=/usr/lib/libreoffice/share/config

# The main script
if [ ! -f images_sifr_original.zip ]; then
  cp $SIFRPATH/images_sifr.zip images_sifr_original.zip
fi
unzip images_sifr_original.zip -d images_sifr
cd images_sifr
find . -name '*.png' -exec mogrify -verbose -fuzz 75% -fill 'rgb(222,222,222)' -opaque 'rgb(66,66,66)' {} \;
zip -rqv ../images_sifr_mogrify.zip *
cd ..

sudo cp images_sifr_mogrify.zip $SIFRPATH/images_sifr.zip
