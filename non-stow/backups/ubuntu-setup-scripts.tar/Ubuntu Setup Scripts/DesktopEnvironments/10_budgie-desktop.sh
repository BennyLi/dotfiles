#!/usr/bin/env bash

sudo add-apt-repository --yes ppa:budgie-remix/ppa
sudo sh -c 'cat >/etc/apt/preferences.d/budgie-remix-ppa-budgie-desktop-pin <<EOL
Package: *
Pin: release o=LP-PPA-budgie-remix-ppa
Pin-Priority: -1

Package: budgie-desktop
Pin: release o=LP-PPA-budgie-remix-ppa
Pin-Priority: 500
EOL'

sudo apt-get update
sudo apt-get install --yes budgie-desktop
