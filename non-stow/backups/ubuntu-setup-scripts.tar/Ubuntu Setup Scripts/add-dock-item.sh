#!/bin/bash
for person in $(ls /home/)
do 
    if [ "$person" != "lost+found" ]
    then 
	    echo "[PlankItemsDockItemPreferences]" >> /home/${person}/.config/plank/dock1/launchers/skype.dockitem
	    echo "Launcher=file:///usr/share/applications/skype.desktop" >> /home/${person}/.config/plank/dock1/launchers/skype.dockitem
    fi
done
