#!/usr/bin/env bash

echo "Trying to install vim..."

# Install VIM
sudo apt-get install --yes vim
