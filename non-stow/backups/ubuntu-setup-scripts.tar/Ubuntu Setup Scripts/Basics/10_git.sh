#!/usr/bin/env bash

echo "Trying to install latest GIT..."

# Install the latest git Version
sudo add-apt-repository --yes ppa:git-core/ppa
sudo sh -c 'cat >/etc/apt/preferences.d/git-core-ppa-git-pin <<EOL
Package: *
Pin: release o=LP-PPA-git-core-ppa
Pin-Priority: -1

Package: git
Pin: release o=LP-PPA-git-core-ppa
Pin-Priority: 500
EOL'

sudo apt-get update
sudo apt-get install --yes git
