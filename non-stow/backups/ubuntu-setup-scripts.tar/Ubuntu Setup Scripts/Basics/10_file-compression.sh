#!/usr/bin/env bash

# Install File Compression Libs
sudo apt-get install --yes unace unrar zip unzip xz-utils p7zip-full p7zip-rar sharutils rar uudeview mpack arj cabextract file-roller
