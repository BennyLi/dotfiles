#!/usr/bin/env bash

# Auto-Accept license
echo ttf-mscorefonts-installer msttcorefonts/accepted-mscorefonts-eula select true | sudo debconf-set-selections
# Install Ubuntu Restricted Extras (Codecs)
sudo apt-get install --yes ubuntu-restricted-extras


# Enable Movie DVD Support
sudo apt-get install --yes libdvdread4
#sudo /usr/share/doc/libdvdread4/install-css.sh
