#!/usr/bin/env bash

CURRPWD="$(pwd)"
for folder in "Basics" "Drivers" "Themes" "Tools" "DesktopEnvironments"
do
  cd $folder
  for setup_script in $(ls -p | grep -v /)
  do
    echo "Executing ./$folder/$setup_script"
    chmod +x $setup_script
    ./$setup_script >>"$CURRPWD/setup.log" 2>&1
    LAST_ERROR=$?
    if [ $LAST_ERROR -ne 0 ]; then
      echo "Something went wrong. Check the log file at $CURRPWD/setup.log"
      echo "Here are the last 10 lines from the log:"
      echo
      tail -n 10 "$CURRPWD/setup.log"
      exit $LAST_ERROR
    fi
  done
  cd ..
done

echo "All done!"
