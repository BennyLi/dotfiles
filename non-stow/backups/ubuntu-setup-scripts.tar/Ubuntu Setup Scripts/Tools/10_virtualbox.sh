#!/usr/bin/env bash

echo "Trying to install VirtualBox 5..."

# Install the latest Version of VirtualBox
# wget -q http://download.virtualbox.org/virtualbox/debian/oracle_vbox.asc -O- | sudo apt-key add -
# sudo add-apt-repository --yes "deb http://download.virtualbox.org/virtualbox/debian $(lsb_release -sc) contrib"
# sudo apt-get update
# sudo apt-get install --yes virtualbox-5.0

sudo apt-get install --yes vde2 virtualbox virtualbox-guest-additions-iso
