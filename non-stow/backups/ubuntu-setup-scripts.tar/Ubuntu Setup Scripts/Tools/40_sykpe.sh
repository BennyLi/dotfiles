#!/usr/bin/env bash

echo "Trying to install Skype..."

# Install Skype
sudo apt-add-repository --yes "deb http://archive.canonical.com/ubuntu/ $(lsb_release -sc) partner"
sudo dpkg --add-architecture i386
sudo apt-get update
sudo apt-get install --yes skype
