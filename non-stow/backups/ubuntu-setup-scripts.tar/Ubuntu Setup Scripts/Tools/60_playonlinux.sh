#!/usr/bin/env bash

# Install PlayOnLinux
sudo apt-get install --yes playonlinux
