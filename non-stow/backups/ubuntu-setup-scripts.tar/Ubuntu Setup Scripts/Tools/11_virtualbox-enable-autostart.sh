#!/usr/bin/env bash

# source: http://lifeofageekadmin.com/how-to-set-your-virtualbox-vm-to-automatically-startup/

cd /etc/init.d/
sudo wget http://www.virtualbox.org/browser/vbox/trunk/src/VBox/Installer/linux/vboxautostart-service.sh?format=raw -O vboxautostart-service
sudo chmod +x vboxautostart-service
sudo sed -i 's/Required-Start: vboxdrv/Required-Start: virtualbox/' vboxautostart-service
sudo sed -i 's/Required-Stop:  vboxdrv/Required-Stop:  virtualbox/' vboxautostart-service
sudo update-rc.d vboxautostart-service defaults

sudo sh -c 'cat >/etc/default/virtualbox <<EOL

SHUTDOWN_USERS="all"
SHUTDOWN=savestate

VBOXAUTOSTART_DB=/etc/vbox
VBOXAUTOSTART_CONFIG=/etc/vbox/vbox-autostart.cfg
EOL'

sudo mkdir /etc/vbox
sudo sh -c 'cat >/etc/vbox/vbox-autostart.cfg <<EOL
# Default policy is to deny starting a VM, the other option is "allow".
default_policy = allow
# Create an entry for each user allowed to run autostart
benny = {
  allow = true
  startup_delay = 10
}
EOL'

sudo chgrp vboxusers /etc/vbox
sudo chmod 1775 /etc/vbox

sudo usermod -G $(groups benny | sed -n 's/benny : benny //p' | sed 's/[ ]/,/g'),vboxusers benny

VBoxManage setproperty autostartdbpath /etc/vbox
#VBoxManage modifyvm "Windows XP SP3" --autostart-enabled on
#sudo service vboxautostart-service restart
