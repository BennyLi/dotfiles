#!/usr/bin/env bash

sudo apt-get install --yes unity-tweak-tool
