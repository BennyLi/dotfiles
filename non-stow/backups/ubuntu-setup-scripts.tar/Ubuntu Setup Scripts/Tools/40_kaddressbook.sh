#!/usr/bin/env bash

echo "Trying to install KAddressBook..."

# Install Addressbook from KDE
sudo apt-get install --yes --no-install-recommends kaddressbook
