#!/usr/bin/env bash

echo "Trying to install KeePassX 2..."

# Install KeePassX 2
sudo add-apt-repository --yes ppa:eugenesan/ppa
sudo sh -c 'cat >/etc/apt/preferences.d/eugenesan-ppa-keepassx-pin <<EOL
Package: *
Pin: release o=LP-PPA-eugenesan-ppa
Pin-Priority: -1

Package: keepassx
Pin: release o=LP-PPA-eugenesan-ppa
Pin-Priority: 500
EOL'

sudo apt-get update
sudo apt-get install --yes keepassx
