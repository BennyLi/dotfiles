#!/bin/bash
# Install VirtualBox extension pack
cd /tmp
VBOX_LATEST_URL='http://download.virtualbox.org/virtualbox/LATEST.TXT'
wget "$VBOX_LATEST_URL"
VBOX_LATEST="$(cat LATEST.TXT)"
echo "Latest VirtualBox version: $VBOX_LATEST"

VBOX_EXT_URL="http://download.virtualbox.org/virtualbox/$VBOX_LATEST/Oracle_VM_VirtualBox_Extension_Pack-$VBOX_LATEST.vbox-extpack"
VBOX_EXT_TMP_FILE="$(pwd)/$(basename $VBOX_EXT_URL)"
wget "$VBOX_EXT_URL"

for person in $(ls /home/)
do
	if [ "$person" != "lost+found" ]
	then
		echo "Installing VirtualBox extension pack for $person"
		sudo sh -c "echo \"$person ALL=(ALL) NOPASSWD: ALL\" > /etc/sudoers.d/installvboxextpack"
		sudo -u $person -i -- sudo vboxmanage extpack install $VBOX_EXT_TMP_FILE
		rm /etc/sudoers.d/installvboxextpack
	fi
done

rm -f "LATEST.TXT"
rm -f $VBOX_EXT_TMP_FILE
unset VBOX_EXT_URL
unset VBOX_EXT_TMP_FILE
