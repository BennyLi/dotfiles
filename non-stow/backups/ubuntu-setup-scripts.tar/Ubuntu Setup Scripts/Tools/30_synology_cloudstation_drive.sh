#!/usr/bin/env bash

echo "Trying to install Synology CloudStation Drive..."

# Install Synology CloudStation Drive
SYNO_CLIENT_URL='http://global.download.synology.com/download/Tools/CloudStationDrive/4.0-4204/Ubuntu/Installer/x86_64/synology-cloud-station-drive-4204.x86_64.deb'
SYNO_CLIENT_TMP_FILE=`mktemp`
wget "$SYNO_CLIENT_URL" -qO $SYNO_CLIENT_TMP_FILE
sudo dpkg -i $SYNO_CLIENT_TMP_FILE
rm $SYNO_CLIENT_TMP_FILE
unset SYNO_CLIENT_URL
unset SYNO_CLIENT_TMP_FILE
