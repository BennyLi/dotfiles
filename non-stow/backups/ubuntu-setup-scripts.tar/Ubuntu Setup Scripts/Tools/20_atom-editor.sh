#!/usr/bin/env bash

sudo add-apt-repository --yes ppa:webupd8team/atom

sudo sh -c 'cat >/etc/apt/preferences.d/webupd8team-atom-pin <<EOL
Package: *
Pin: release o=LP-PPA-webupd8team-atom
Pin-Priority: -1

Package: atom
Pin: release o=LP-PPA-webupd8team-atom
Pin-Priority: 500
EOL'

sudo apt-get update
sudo apt-get install --yes atom
