#!/usr/bin/env bash

# Install Java 8
sudo add-apt-repository --yes ppa:webupd8team/java
sudo sh -c 'cat >/etc/apt/preferences.d/webupd8tean-java-oracle-java8-installer-pin <<EOL
Package: *
Pin: release o=LP-PPA-webupd8team-java
Pin-Priority: -1

Package: oracle-java8-installer
Pin: release o=LP-PPA-webupd8team-java
Pin-Priority: 500
EOL'

# Auto-Accept license
echo debconf shared/accepted-oracle-license-v1-1 select true | sudo debconf-set-selections
echo debconf shared/accepted-oracle-license-v1-1 seen true | sudo debconf-set-selections

sudo apt-get update
sudo apt-get install --yes oracle-java8-installer
