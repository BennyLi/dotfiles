#!/usr/bin/env bash

# Install Canon network printer drivers
sudo apt-get install --yes cups-backend-bjnp
